#!/usr/bin/env bash
set -euo pipefail
# Isolated install: Windows Go emits .exe; never remove source cwd.
cd "$(dirname "${BASH_SOURCE[0]}")"
GO_BIN="${GO_BIN:-F:/tools/go1.26.5/go/bin/go.exe}"
export GOROOT="${GOROOT:-F:/tools/go1.26.5/go}"
export GOPATH="${GOPATH:-$($GO_BIN env GOPATH)}"
export GOBIN="${GOBIN:-F:/pskora-lab/native-build-lab/tools}"
export GOCACHE="${GOCACHE:-F:/tools/go-cache}"
export GOMODCACHE="${GOMODCACHE:-F:/tools/go-mod-cache}"
export GOTOOLCHAIN=local
export PATH="$(cygpath -u "$GOBIN"):$(cygpath -u "$GOROOT/bin"):$PATH"
EXE=""
case "$($GO_BIN env GOHOSTOS)" in windows) EXE=.exe;; esac
SOURCE="${GOMOBILE_SOURCE:-F:/pskora-lab/gomobile-src}"
mkdir -p "$GOBIN"
# Subshell restores cwd automatically; explicit output avoids GOBIN/name ambiguity.
(
 cd "$SOURCE"
 "$GO_BIN" build -o "$GOBIN/gomobile-matsuri$EXE" ./cmd/gomobile
 "$GO_BIN" build -o "$GOBIN/gobind-matsuri$EXE" ./cmd/gobind
)
export GOBIND="$GOBIN/gobind-matsuri$EXE"
"$GOBIN/gomobile-matsuri$EXE" init
