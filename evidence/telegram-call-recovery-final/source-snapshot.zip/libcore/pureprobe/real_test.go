package pureprobe

import (
 "context"
 "encoding/json"
 "io"
 "net"
 "net/http"
 "net/url"
 "os"
 "strconv"
 "testing"
 "time"
 box "github.com/sagernet/sing-box"
 "github.com/sagernet/sing-box/include"
 "github.com/sagernet/sing-box/option"
)

func TestRealCorePure(t *testing.T){
 if os.Getenv("PURE_REAL")!="1" {t.Skip("explicit credential use only")}
 raw,e:=os.ReadFile("F:/pskora-lab/pure-lab/go-proxy/config.private.json");if e!=nil {t.Fatal("credential read failed")}
 var cfg struct{UUID string `json:"uuid"`; Nodes []string `json:"nodes"`; AllowInsecure bool `json:"allowInsecure"`}
 if json.Unmarshal(raw,&cfg)!=nil {t.Fatal("credential format")}
 type result struct{Node int `json:"node"`; URL string `json:"url"`; Status int `json:"status"`; Bytes int `json:"bytes"`; Error string `json:"error,omitempty"`}
 var results []result
 for i,node:=range cfg.Nodes {
 host,port,e:=net.SplitHostPort(node);if e!=nil {t.Fatal("endpoint format")};pn,_:=strconv.Atoi(port)
 listener,e:=net.Listen("tcp","127.0.0.1:0");if e!=nil {t.Fatal(e)};lp:=listener.Addr().(*net.TCPAddr).Port;listener.Close()
 config:=map[string]any{"log":map[string]any{"disabled":true},"inbounds":[]any{map[string]any{"type":"mixed","listen":"127.0.0.1","listen_port":lp}},"outbounds":[]any{map[string]any{"type":"vless","tag":"pure","server":host,"server_port":pn,"uuid":cfg.UUID+"#pure","tls":map[string]any{"enabled":true,"insecure":cfg.AllowInsecure},"transport":map[string]any{"type":"ws","path":"/websocket"}}}}
 data,_:=json.Marshal(config);ctx:=include.Context(context.Background());var opts option.Options
 if e=opts.UnmarshalJSONContext(ctx,data);e!=nil {t.Fatal("parse failed")}
 b,e:=box.New(box.Options{Context:ctx,Options:opts});if e!=nil {t.Fatal("core creation failed: ",e)}
 if e=b.Start();e!=nil {t.Fatal("core start failed")}
 proxy,_:=url.Parse("http://127.0.0.1:"+strconv.Itoa(lp));tr:=&http.Transport{Proxy:http.ProxyURL(proxy),DisableKeepAlives:true};cl:=&http.Client{Transport:tr,Timeout:35*time.Second}
 for _,target:=range []string{"https://www.google.com/generate_204","https://example.com/"}{
 r:=result{Node:i+1,URL:target};resp,e:=cl.Get(target)
 if e!=nil {r.Error="request failed";t.Errorf("node %d HTTPS failed: %v",i+1,e)}else{body,err:=io.ReadAll(resp.Body);resp.Body.Close();r.Status=resp.StatusCode;r.Bytes=len(body);if err!=nil {r.Error="body read failed";t.Error("body read failed")};if (target=="https://example.com/" && (r.Status!=200 || r.Bytes<100)) || (target!="https://example.com/" && r.Status!=204){t.Error("bad response")}}
 results=append(results,r);t.Logf("node=%d status=%d bytes=%d",r.Node,r.Status,r.Bytes)
 };tr.CloseIdleConnections();b.Close()
 }
 data,_:=json.MarshalIndent(results,"","  ");if os.WriteFile("F:/pskora-lab/core115-migration/evidence/pure-integration/real-network.json",data,0600)!=nil {t.Fatal("evidence write")}
}
